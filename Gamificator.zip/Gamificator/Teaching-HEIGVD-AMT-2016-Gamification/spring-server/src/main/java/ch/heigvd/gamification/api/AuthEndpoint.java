/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.gamification.api;

import ch.heigvd.gamification.api.dto.Credentials;
import ch.heigvd.gamification.api.dto.Token;
import ch.heigvd.gamification.dao.ApplicationRepository;
import ch.heigvd.gamification.model.Application;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Thibaut-PC
 */

@RestController
public class AuthEndpoint implements AuthenticationsApi {

    private ApplicationRepository applicationsRepository;

    @Autowired
    public AuthEndpoint(ApplicationRepository applicationsRepository) {
        this.applicationsRepository = applicationsRepository;
    }

    @Override
    public ResponseEntity authenticateApplicationAndGetToken(@ApiParam(value = "The info required to authenticate an application", required = true) @RequestBody Credentials body) {

        String applicationName = body.getApplicationName();

        String password = body.getPassword();

        Application app = applicationsRepository.findByName(applicationName);

        if (app != null) {
            Token token = new Token();
            token.setApplicationName(app.getName());
            return ResponseEntity.ok(token);
        } else {

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        }

    }
}
