/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.gamification.api;

import ch.heigvd.gamification.api.dto.EventDTO;
import ch.heigvd.gamification.dao.ApplicationRepository;
import ch.heigvd.gamification.dao.BadgeAwardRepository;
import ch.heigvd.gamification.dao.BadgeRepository;
import ch.heigvd.gamification.dao.EndUserRepository;
import ch.heigvd.gamification.dao.EventTypeRepository;
import ch.heigvd.gamification.dao.PointAwardsRepository;
import ch.heigvd.gamification.dao.RulePropertiesRepository;
import ch.heigvd.gamification.dao.RuleRepository;
import ch.heigvd.gamification.model.ActionBadge;
import ch.heigvd.gamification.model.ActionPoints;
import ch.heigvd.gamification.model.Application;
import ch.heigvd.gamification.model.BadgeAward;
import ch.heigvd.gamification.model.EndUser;
import ch.heigvd.gamification.model.EventType;
import ch.heigvd.gamification.model.PointAwards;
import ch.heigvd.gamification.model.Rule;
import io.swagger.annotations.ApiParam;
import java.util.List;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Thibaut-PC
 */
@RestController
@RequestMapping(value = "/events")
public class EventsEndpoint implements EventsApi {

    EventTypeRepository eventTypeRepository;

    EndUserRepository endUserRepository;

    ApplicationRepository ApplicationRepository;

    RuleRepository ruleRepository;

    RulePropertiesRepository rulesPropertiesRepository;

    PointAwardsRepository pointAwardsrepository;

    BadgeAwardRepository badgeAwardRepository;

    BadgeRepository badgeRepository;

    @Autowired
    public EventsEndpoint(EventTypeRepository eventypeRepository, EndUserRepository endUserRepository, ApplicationRepository ApplicationRepository, RuleRepository ruleRepository, RulePropertiesRepository rulesPropertiesRepository, PointAwardsRepository pointawardsrepository, BadgeAwardRepository badgeAwardRepository, BadgeRepository badgeRepository) {
        this.eventTypeRepository = eventypeRepository;
        this.endUserRepository = endUserRepository;
        this.ApplicationRepository = ApplicationRepository;
        this.ruleRepository = ruleRepository;
        this.rulesPropertiesRepository = rulesPropertiesRepository;
        this.pointAwardsrepository = pointawardsrepository;
        this.badgeAwardRepository = badgeAwardRepository;
        this.badgeRepository = badgeRepository;
    }

    /**
     *
     * @param xGamificationToken
     * @param event
     * @return
     */
    @Override
    public ResponseEntity reportEvent(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "The event that occured in the realm of the gamified application", required = true) @RequestBody EventDTO event) {

        Long idendUser = event.getUserId();
        DateTime timestamp = event.getTimeStamp();
        String type = event.getType();
        Application app = null;
        EndUser enduser;

        app = ApplicationRepository.findByName(xGamificationToken);

        // enduser = endUserRepository.findOne(body.getUserId());
        if (app == null) {

            return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).build();

        }

        enduser = endUserRepository.findByIdAndApp(event.getUserId(), app);

        if (enduser == null) {
            enduser = endUserRepository.save(new EndUser(event.getType(), timestamp.toDate(), app));

        }

        EventType eventype = null;

        String eventypeName = event.getType();

        eventype = eventTypeRepository.findByEventNameAndApp(eventypeName, app);

        //  List<RuleProperties> ruleProperties = new ArrayList<>();
        List<Rule> rules = eventype.getRules();

        if (rules.size() > 0) {
            for (Rule r : rules) {

                switch (r.getActionType().getClass().getSimpleName()) {
                    case "ActionPoints":
                        ActionPoints ap = (ActionPoints) r.getActionType();
                        pointAwardsrepository.save(new PointAwards(enduser, ap.getNombrePoint(), r.getPointscale()));
                        break;
                    case "ActionBadge":
                        ActionBadge ab = (ActionBadge) r.getActionType();
                        badgeAwardRepository.save(new BadgeAward(timestamp.toDate(), ab.getBadge(), enduser));
                }

            }
        }

        return ResponseEntity.accepted().build();
    }
}
