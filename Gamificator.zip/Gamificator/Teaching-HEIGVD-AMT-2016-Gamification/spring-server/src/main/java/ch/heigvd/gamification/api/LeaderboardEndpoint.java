package ch.heigvd.gamification.api;

import ch.heigvd.gamification.api.dto.LeaderboardDTO;
import io.swagger.annotations.ApiParam;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by Thibaut-PC on 15.12.16.
 */
public class LeaderboardEndpoint implements LeaderboardApi {
    @Override
    public ResponseEntity<LeaderboardDTO> leaderboardGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "nombre de leaders à afficher") @RequestParam(value = "size", required = false) Integer size) {
        return null;
    }
}
