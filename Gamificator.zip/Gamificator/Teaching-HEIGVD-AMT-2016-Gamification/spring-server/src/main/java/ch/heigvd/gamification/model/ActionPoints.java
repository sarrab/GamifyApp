/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.gamification.model;

import javax.persistence.Entity;

/**
 *
 * @author Thibaut-PC
 *
 */
@Entity
public class ActionPoints extends ActionType {

    private int nbrePoint;

    public ActionPoints() {
    }

    public ActionPoints(int nombrePoint, String name) {
        this.nbrePoint = nombrePoint;
    }

    public int getNombrePoint() {
        return nbrePoint;
    }

    public void setNombrePoint(int nombrePoint) {
        this.nbrePoint = nombrePoint;
    }

    public int getNbrePoint() {
        return nbrePoint;
    }

    public void setNbrePoint(int nbrePoint) {
        this.nbrePoint = nbrePoint;
    }

}
