package ch.heigvd.gamification.api;

import ch.heigvd.gamification.api.dto.BadgeDTO;
import ch.heigvd.gamification.api.dto.EndUserDTO;
import ch.heigvd.gamification.api.dto.EndUserReputationDTO;
import ch.heigvd.gamification.dao.ApplicationRepository;
import ch.heigvd.gamification.dao.EndUserRepository;
import ch.heigvd.gamification.model.Application;
import ch.heigvd.gamification.model.Badge;
import ch.heigvd.gamification.model.EndUser;
import ch.heigvd.gamification.model.PointAwards;
import io.swagger.annotations.ApiParam;
import java.util.ArrayList;
import java.util.List;
import static java.util.stream.Collectors.toList;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by Thibaut-PC on 15.12.16.
 */
@Controller
public class EndUserEndpoint implements EndUserApi {

    EndUserRepository endUserRepository;

    ApplicationRepository applicationRepository;

    @Autowired
    public EndUserEndpoint(EndUserRepository endUserRepository, ApplicationRepository applicationRepository) {
        this.endUserRepository = endUserRepository;
        this.applicationRepository = applicationRepository;
    }

    @Override
    public ResponseEntity<Void> endUserEndUserNameBadgesGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "user's name", required = true) @PathVariable("endUserName") String endUserName) {

        Application app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            EndUser endUser = endUserRepository.findByNameAndApp(endUserName, app);

            if (endUser != null) {

                List<BadgeDTO> badgesDTO = new ArrayList<>();

                endUser.getBadgeAwards().stream().map((b) -> {
                    BadgeDTO badgeDto = new BadgeDTO();
                    Badge badge = b.getBadge();
                    badgeDto.setDescription(badge.getDescription());
                    badgeDto.setImageURI(badge.getImage());
                    badgeDto.setName(badge.getName());
                    return badgeDto;
                }).forEach((badgeDto) -> {
                    badgesDTO.add(badgeDto);
                });
                return new ResponseEntity(badgesDTO, HttpStatus.OK);
            }

        }

        return new ResponseEntity("No content available", HttpStatus.BAD_REQUEST);
    }

    @Override
    public ResponseEntity<EndUserReputationDTO> endUserEndUserNameReputationGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "user's name", required = true) @PathVariable("endUserName") String endUserName) {

        Application app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            EndUser endUser = endUserRepository.findByNameAndApp(endUserName, app);

            if (endUser != null) {

                System.out.println("endUserName" + endUserName);
                System.out.println("endUser" + endUser.getID());

                EndUserReputationDTO dto = new EndUserReputationDTO();
                List<PointAwards> poindAwards = endUserRepository.findByName(endUserName).getPointAwards();
                Long point;
                point = 0L;

                point = poindAwards.stream().map((p) -> p.getPoint()).reduce(point, (accumulator, _item) -> accumulator + _item);

                System.out.println("points" + point);

                dto.setPoints(point);

                List<BadgeDTO> badgeDtos = new ArrayList();

                endUser.getBadgeAwards().stream().map((b) -> {
                    BadgeDTO badgedto = new BadgeDTO();
                    Badge badge = b.getBadge();
                    badgedto.setDescription(badge.getDescription());
                    badgedto.setImageURI(badge.getImage());
                    badgedto.setName(badge.getName());
                    return badgedto;
                }).forEach((badgedto) -> {
                    badgeDtos.add(badgedto);
                });
                dto.setBadge(badgeDtos);

                return new ResponseEntity(dto, HttpStatus.OK);
            }

        }

        return new ResponseEntity("No content is available", HttpStatus.BAD_REQUEST);
    }

    @Override
    @RequestMapping(value = "/{token that identifies the app sending the request}", method = RequestMethod.GET)
    public ResponseEntity<EndUserDTO> endUserGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken) {

        return new ResponseEntity<>((EndUserDTO) StreamSupport.stream(endUserRepository.findAll().spliterator(), true)
                .map(p -> toDTO(p))
                .collect(toList()), HttpStatus.OK);
    }

    @Override
    @RequestMapping(value = "/{token that identifies the app sending the request}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> endUserIdDelete(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "user's id", required = true) @PathVariable("id") Long id) {

        Application app = applicationRepository.findByName(xGamificationToken);
        if (app != null) {

            EndUser endUser = endUserRepository.findByIdAndApp(id, app);
            endUserRepository.delete(endUser);
            return new ResponseEntity(HttpStatus.OK);
        } else {

            return new ResponseEntity(HttpStatus.BAD_REQUEST);

        }

    }

    @Override
    @RequestMapping(value = "/{token that identifies the app sending the request}", method = RequestMethod.POST)
    public ResponseEntity<EndUserDTO> endUserPost(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "données de l'utilisateur", required = true) @RequestBody EndUserDTO body) {

        EndUser endUser = new EndUser();

        endUser.setName(body.getName());
        Application app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            endUser.setApp(app);
            if (endUserRepository.findByIdAndApp(endUser.getID(), app) != null) {

                return new ResponseEntity("this user already exixts", HttpStatus.BAD_REQUEST);
            } else {

                return new ResponseEntity(HttpStatus.CREATED);

            }

        }

        return new ResponseEntity("No content available", HttpStatus.BAD_REQUEST);

    }

    @Override
    //RequestMapping(value = "/{token that identifies the app sending the request}", method = RequestMethod.GET)
    public ResponseEntity<EndUserDTO> endUserIdGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "user's id", required = true) @PathVariable("id") Long id) {
        Application app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            EndUser endUser = endUserRepository.findByIdAndApp(id, app);
            if (endUser != null) {
                EndUserDTO endUserDto = new EndUserDTO();

                endUserDto.setName(endUser.getName());

                return new ResponseEntity(endUserDto, HttpStatus.OK);
            }

        }

        return new ResponseEntity("no content available", HttpStatus.BAD_REQUEST);
    }

    @Override
    @RequestMapping(value = "/{token that identifies the app sending the request}", method = RequestMethod.PUT)
    public ResponseEntity<Void> endUserIdPut(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "user's id", required = true) @PathVariable("id") Long id, @ApiParam(value = "Update of a user") @RequestBody EndUserDTO body) {

        Application app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            EndUser endUser = endUserRepository.findByIdAndApp(id, app);

            if (endUser != null) {

                if (body.getName().equals(" ")) {

                    endUser.setName(body.getName());

                } else {

                    body.setName(endUser.getName());

                }

            }

            endUserRepository.save(endUser);
            return new ResponseEntity(HttpStatus.OK);

        }

        return new ResponseEntity("no content available", HttpStatus.BAD_REQUEST);
    }

    public EndUserDTO toDTO(EndUser endUser) {
        EndUserDTO endUserDto = new EndUserDTO();

        endUserDto.setName(endUser.getName());
        return endUserDto;
    }

}
