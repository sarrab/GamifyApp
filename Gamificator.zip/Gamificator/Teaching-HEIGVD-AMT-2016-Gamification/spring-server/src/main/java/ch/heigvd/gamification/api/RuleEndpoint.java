package ch.heigvd.gamification.api;

import ch.heigvd.gamification.api.dto.RuleDTO;
import ch.heigvd.gamification.dao.ActionBadgeRepository;
import ch.heigvd.gamification.dao.ActionPointRepository;
import ch.heigvd.gamification.dao.ApplicationRepository;
import ch.heigvd.gamification.dao.BadgeRepository;
import ch.heigvd.gamification.dao.EventTypeRepository;
import ch.heigvd.gamification.dao.PointScaleRepository;
import ch.heigvd.gamification.dao.RuleRepository;
import ch.heigvd.gamification.model.ActionBadge;
import ch.heigvd.gamification.model.ActionPoints;
import ch.heigvd.gamification.model.ActionType;
import ch.heigvd.gamification.model.Application;
import ch.heigvd.gamification.model.EventType;
import ch.heigvd.gamification.model.PointScale;
import ch.heigvd.gamification.model.Rule;
import io.swagger.annotations.ApiParam;
import static java.util.stream.Collectors.toList;
import java.util.stream.StreamSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by Thibaut-PC on 13.12.16.
 */
@RestController
@RequestMapping(value = "/rules")
public class RuleEndpoint implements RulesApi {

    RuleRepository rulerepository;

    PointScaleRepository pointScaleRepository;
    EventTypeRepository eventTypeRepository;
    ApplicationRepository applicationRepository;
    BadgeRepository badgerepository;
    ActionBadgeRepository actionBadgerepository;
    ActionPointRepository actionPointsrepository;
    final String ACTION_TYPE_POINT_FINAL = " AwardPoints";
    final String ACTION_TYPE_BADGE_FINAL = " AwardBadge";

    @Autowired
    public RuleEndpoint(RuleRepository rulerepository, PointScaleRepository pointScaleRepository, EventTypeRepository eventTypeRepository, ApplicationRepository applicationRepository, BadgeRepository badgerepository, ActionBadgeRepository actionBadgerepository, ActionPointRepository actionPointsrepository) {
        this.rulerepository = rulerepository;
        this.pointScaleRepository = pointScaleRepository;
        this.eventTypeRepository = eventTypeRepository;
        this.applicationRepository = applicationRepository;
        this.badgerepository = badgerepository;
        this.actionBadgerepository = actionBadgerepository;
        this.actionPointsrepository = actionPointsrepository;
    }

    @Override
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<RuleDTO> rulesGet(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken) {

        return new ResponseEntity<>((RuleDTO) StreamSupport.stream(rulerepository.findAll().spliterator(), true)
                .map(p -> toDTO(p))
                .collect(toList()), HttpStatus.OK);

    }

    @Override
    public ResponseEntity<RuleDTO> rulesPost(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "paramètres de la règles créée", required = true) @RequestBody RuleDTO body) {

        Application app = null;
        EventType eventype = new EventType();
        Rule rule = new Rule();
        ActionType action;

        app = applicationRepository.findByName(xGamificationToken);

        if (app != null) {

            eventype = eventTypeRepository.findByEventNameAndApp(body.getEvent(), app);
            if (eventype == null) {
                eventype.setApp(app);
                eventype.setEventName(body.getEvent());
                eventTypeRepository.save(eventype);

            }

            rule.setEventyp(eventype);

            PointScale pointScale = pointScaleRepository.findByName(body.getPointScale());

            if (pointScale != null) {
                rule.setPointscale(pointScale);

            }

            if (body.getAction().equalsIgnoreCase(ACTION_TYPE_POINT_FINAL)) {

                ActionPoints actionpoint;

                actionpoint = actionPointsrepository.findBynbrePoint(body.getPoints());

                if (actionpoint == null) {

                    actionpoint.setNombrePoint(body.getPoints());
                    actionpoint.setName("ActionPoints");

                }
                rule.setActionType(actionpoint);

            }

            if (body.getAction().equals(ACTION_TYPE_BADGE_FINAL)) {
                ActionBadge actionbadge;

                actionbadge = actionBadgerepository.findBybadge(body.getBadgeId());

                if (actionbadge == null) {

                    ActionBadge actionBadge = new ActionBadge();

                    actionbadge.setName("ActionBadge");
                    actionbadge.setBadge(badgerepository.findOne(body.getBadgeId()));

                }

                rule.setActionType(actionbadge);
            }
            rulerepository.save(rule);

            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

    }

    @Override
    @RequestMapping(value = "/{Rule's id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> rulesRuleIdDelete(@ApiParam(value = "Rule's id", required = true) @PathVariable("ruleId") Long ruleId) {

        Rule rule = rulerepository.findOne(ruleId);

        if (rule != null) {
            rulerepository.delete(rule);
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    @RequestMapping(value = "/{rule's id}", method = RequestMethod.GET)
    public ResponseEntity<RuleDTO> rulesRuleIdGet(@ApiParam(value = "rule's id", required = true) @PathVariable("ruleId") Long ruleId) {
        Rule rule = rulerepository.findOne(ruleId);

        if (rule != null) {
            RuleDTO dto = toDTO(rule);

            return new ResponseEntity(HttpStatus.CREATED);
        } else {

            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

    }

    @Override
    public ResponseEntity<Void> rulesRuleIdPut(@ApiParam(value = "token that identifies the app sending the request", required = true) @RequestHeader(value = "X-Gamification-Token", required = true) String xGamificationToken, @ApiParam(value = "Rule's id", required = true) @PathVariable("ruleId") Long ruleId, @ApiParam(value = "Modification of the Rule") @RequestBody RuleDTO body) {
        Rule rule = rulerepository.findOne(ruleId);

        if (!body.getAction().equals(" ")) {
            switch (rule.getActionType().getClass().getSimpleName()) {
                case "ActionPoints":
                    ActionPoints ap = actionPointsrepository.findBynbrePoint(body.getPoints());
                    if (ap != null) {
                        rule.setActionType(ap);
                    }
                    break;
                case "ActionBadge":
                    ActionBadge ab = actionBadgerepository.findBybadge(body.getBadgeId());
                    if (ab != null) {

                        rule.setActionType(ab);

                    }
            }
        }

        if (!body.getEvent().equals(" ")) {
            rule.setEventType(eventTypeRepository.findByEventName(body.getEvent()));
        } else {
            body.event(rule.getEventType().getEventName());
        }

        if (!body.getPointScale().equals(" ")) {
            rule.setPointscale(pointScaleRepository.findByName(body.getPointScale()));
        } else {
            body.event(rule.getEventType().getEventName());
        }

        rulerepository.save(rule);
        return new ResponseEntity(HttpStatus.OK);
    }

    public RuleDTO toDTO(Rule rule) {
        RuleDTO ruleDto = new RuleDTO();

        ruleDto.setAction(rule.getActionType().getName());
        switch (rule.getActionType().getClass().getSimpleName()) {
            case "ActionPoints":
                ActionPoints ap = (ActionPoints) rule.getActionType();
                ruleDto.setPoints(ap.getNbrePoint());
                break;
            case "ActionBadge":
                ActionBadge ab = (ActionBadge) rule.getActionType();
                ruleDto.setBadgeId(ab.getId());
        }
        ruleDto.setEvent(rule.getEventType().getEventName());
        ruleDto.setPointScale(rule.getPointscale().getName());

        return ruleDto;
    }

}
