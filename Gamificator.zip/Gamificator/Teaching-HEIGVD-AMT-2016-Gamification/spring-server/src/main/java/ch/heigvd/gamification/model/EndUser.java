/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.gamification.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author Thibaut-PC
 */
@Entity
public class EndUser implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    
    @OneToMany(mappedBy = "enduser")
    private List<PointAwards> pointAwards;

    @OneToMany(mappedBy = "endUser")
    private List<BadgeAward> badgeAwards;

    public List<BadgeAward> getBadgeAwards() {
        return badgeAwards;
    }

    public void setBadgeAwards(List<BadgeAward> badgeAwards) {
        this.badgeAwards = badgeAwards;
    }

    private String name;
    private Date date;

    @ManyToOne
    private Application app;

    public EndUser(String name, Date date, Application app) {

        this.name = name;
        this.date = date;
        this.app = app;
    }

    public void setPointAwards(List<PointAwards> pointAwards) {
        this.pointAwards = pointAwards;
    }

    public List<PointAwards> getPointAwards() {
        return pointAwards;
    }

    public EndUser() {
    }

    public String getName() {
        return name;
    }

    public Date getDate() {
        return date;
    }

    public Application getApp() {
        return app;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setApp(Application app) {
        this.app = app;
    }

    public Long getID() {
        return id;
    }

    public void setID(Long ID) {
        this.id = ID;
    }

}
